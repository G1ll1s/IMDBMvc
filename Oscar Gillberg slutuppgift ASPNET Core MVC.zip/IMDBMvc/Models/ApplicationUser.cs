﻿using Microsoft.AspNetCore.Identity;

namespace IMDBMvc.Models
{
    public class ApplicationUser : IdentityUser
    {

    }
}
